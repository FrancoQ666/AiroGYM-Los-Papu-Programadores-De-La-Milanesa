import sqlite3
import funciones
def inicio_sesion():
    print("Inicio de sesion:")
    correo = input("Ponga su Correo: ").strip()
    contrasenia = input("Ponga su Contraseña: ").strip()

    conexion = sqlite3.connect("Usuarios_Registrados.db")
    cursor = conexion.cursor()
    cursor.execute(
        "SELECT nombre, apellido, edad, telefono, correo, dni, Suscripcion, Tiempo FROM usuarios WHERE correo = ? AND contrasenia = ?",
        (correo, contrasenia)
    )
    usuario = cursor.fetchone()


    if usuario:
        print("¿Este es tu cuenta?")
        print(f"""
        Nombre completo: {usuario [0]} || {usuario [1]}
        telefono: {usuario [3]}        
        """)
        x = input("(1)Si || (2)No")
        if x == "1":
            funciones.print_bold(f"Bienvenido {usuario[1]}")
            return{
                "nombre": usuario[0],
                "apellido": usuario[1],
                "edad": usuario[2],
                "telefono": usuario [3],
                "correo": usuario[4],
                "DNI": usuario[5],
                "suscripcion": usuario[6],
                "tiempo": usuario[7]
            }
        else:
            print("Cerrando...")
    else:
        print("Correo o contraseña incorrectos.")
    cursor.close()
    conexion.close()