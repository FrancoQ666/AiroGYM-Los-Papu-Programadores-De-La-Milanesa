import time
import registrer, login
import funciones
import Usuario_actual


def menu_inicio():
    
    while True:
        funciones.limpiar_pantalla()
        funciones.print_centered("--- Menú de inicio ---")
        print("1. Iniciar sesión")
        print("2. Registrarse")
        print("3. Salir")

        opcion = input("Opcion: ")

        if opcion == "1":
            funciones.limpiar_pantalla()
            usuario = login.inicio_sesion()
            if usuario: # En caso que el usuario inicio sesion correctamente
                Usuario_actual.usuario_actual = usuario
                Usuario_actual.menu_usuario()
            time.sleep(1)
        elif opcion == "2":
            funciones.limpiar_pantalla()

            registrer.registrar()
            time.sleep(1)
        elif opcion == "3":
            print("Hasta luego.")
            break
        else:
            print("Opción invalida.")
        time.sleep(1)
menu_inicio()


