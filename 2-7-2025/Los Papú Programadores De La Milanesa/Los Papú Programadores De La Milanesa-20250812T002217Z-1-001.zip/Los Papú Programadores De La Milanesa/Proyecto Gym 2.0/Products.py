import sqlite3

DB_NAME = "gym.db"

def crear_tabla_productos():
    conexion = sqlite3.connect(DB_NAME)
    cursor = conexion.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS productos(
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           nombre TEXT NOT NULL,
           categoria TEXT NOT NULL,
           precio REAL NOT NULL,
           stock INTEGER  NOT NULL,
           stock_minimo INTEGER NOT NULL
           )
    """)
    conexion.commit()
    conexion.close()


def agregar_productos(nombre, categoria, precio, stock, stock_minimo):
    conexion = sqlite3.connect(DB_NAME)
    cursor = conexion.cursor()
    cursor.execute("INSERT INTO productos (nombre, categoria, precio, stock, stock_minimo) VALUES (?, ?, ?, ?, ?)", (nombre,categoria,precio,stock, stock_minimo))
    conexion.commit()
    conexion.close()
    print(f"El producto '{nombre}' se ha agregado correctamente")

def mostrar_productos():
    conexion = sqlite3.connect(DB_NAME)
    cursor = conexion.cursor()
    cursor.execute("SELECT id, nombre, categoria, precio, stock FROM productos")
    for pod in cursor.fetchall():
        print(pod)
    conexion.close()


def productos_escasez():
    conexion = sqlite3.connect(DB_NAME)
    cursor = conexion.cursor()
    cursor.execute("SELECT nombre, stock FROM productos WHERE stock <= stock_minimo")
    productos = cursor.fetchall()
    conexion.close()
    return productos