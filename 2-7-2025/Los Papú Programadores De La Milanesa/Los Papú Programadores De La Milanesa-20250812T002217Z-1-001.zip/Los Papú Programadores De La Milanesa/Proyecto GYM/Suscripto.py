"""
Nuevo Sucripto: Suscripto.py
tiempo: 2023-10-30 20:00:00

"""